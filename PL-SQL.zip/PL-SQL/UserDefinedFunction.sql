SET SERVEROUTPUT ON;

DECLARE
    v_first_name  VARCHAR2(50) := 'John';
    v_salary      NUMBER(8, 2) := 5500.00;
    v_hire_date   DATE := SYSDATE;
    v_is_active   BOOLEAN := TRUE;
BEGIN
    DBMS_OUTPUT.PUT_LINE('Name: ' || v_first_name);
    DBMS_OUTPUT.PUT_LINE('Salary: ' || v_salary);
END;

/
DECLARE v_total NUMBER; 
BEGIN v_total := calculate_annual_salary(5000, 10000);    
DBMS_OUTPUT.PUT_LINE('Total Annual Salary: ' || v_total); 
END; 
/

SELECT employee_name, calculate_annual_salary(monthly_salary, 5000) AS annual_comp FROM employees;