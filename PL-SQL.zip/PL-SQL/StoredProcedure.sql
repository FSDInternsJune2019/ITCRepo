CREATE OR REPLACE PROCEDURE get_employee_salary (
p_emp_id IN employees.employee_id%TYPE,
p_salary OUT employees.salary%TYPE
) AS
BEGIN
SELECT salary
INTO p_salary
FROM employees
WHERE employee_id = p_emp_id;

EXCEPTION
WHEN NO_DATA_FOUND THEN
p_salary := NULL; -- Handles case where employee_id doesn't exist
END get_employee_salary;
/

SET SERVEROUTPUT ON;

DECLARE
v_salary employees.salary%TYPE;
BEGIN
-- Call the procedure
get_employee_salary(p_emp_id => 101, p_salary => v_salary);

-- Display the result
DBMS_OUTPUT.PUT_LINE('Employee Salary: ' || v_salary);
END;
/

