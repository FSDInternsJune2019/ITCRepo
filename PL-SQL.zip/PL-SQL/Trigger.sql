-- Step 1: 
Create an audit table CREATE TABLE audit_logs (emp_id  NUMBER, old_salary  NUMBER,    new_salary  NUMBER, updated_by  VARCHAR2(50), updated_at  DATE ); 
/

-- Step 2: Create the trigger 
CREATE OR REPLACE TRIGGER trg_emp_salary_audit 
AFTER UPDATE OF salary ON employees 
FOR EACH ROW 
BEGIN    
-- :OLD references original data, :NEW references modified data    

INSERT INTO audit_logs (emp_id, old_salary, new_salary, updated_by, updated_at)    VALUES (:OLD.emp_id, :OLD.salary, :NEW.salary, USER, SYSDATE); 
END; 
/

-- This update will automatically fire 'trg_emp_salary_audit' 

UPDATE employees SET salary = 82000 WHERE emp_id = 101;