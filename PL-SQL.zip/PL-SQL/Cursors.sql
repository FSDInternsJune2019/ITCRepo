SET SERVEROUTPUT ON;

DECLARE
    -- 1. DECLARE the cursor with a SELECT statement
    CURSOR c_employees IS
        SELECT employee_id, first_name, salary
        FROM employees
        WHERE department_id = 10;
        
    -- Declare a record variable to hold the fetched row data
    v_emp_rec c_employees%ROWTYPE;
BEGIN
    -- 2. OPEN the cursor to execute the query and allocate memory
    OPEN c_employees;
    
    -- Loop through the results
    LOOP
        -- 3. FETCH data row by row into the record variable
        FETCH c_employees INTO v_emp_rec;
        
        -- Exit the loop when there are no more rows left
        EXIT WHEN c_employees%NOTFOUND;
        
        -- Process/Display the data
        DBMS_OUTPUT.PUT_LINE('ID: ' || v_emp_rec.employee_id || 
                             ' | Name: ' || v_emp_rec.first_name || 
                             ' | Salary: ' || v_emp_rec.salary);
    END LOOP;
    
    -- 4. CLOSE the cursor to release memory
    CLOSE c_employees;
    
EXCEPTION
    WHEN OTHERS THEN
        -- Ensure cursor is closed if an error occurs
        IF c_employees%ISOPEN THEN
            CLOSE c_employees;
        END IF;
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/