package com.itc.service;

import java.util.List;

import com.itc.exception.EmployeeException;
import com.itc.model.EmployeesModel;

public interface EmployeesService {

	public List<EmployeesModel> retrieveEmployees()throws EmployeeException;
	public String saveEmployees(EmployeesModel employeesModel)throws EmployeeException;
	
	
}
