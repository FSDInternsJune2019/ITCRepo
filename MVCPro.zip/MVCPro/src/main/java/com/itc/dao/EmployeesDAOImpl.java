package com.itc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.itc.entities.Employees;
import com.itc.helper.ConnectionManager;

public class EmployeesDAOImpl implements EmployeesDAO {

	@Override
	public List<Employees> get() throws ClassNotFoundException, SQLException {
		
		Connection connection=ConnectionManager.openConnection();
		Statement statement=connection.createStatement();
		ResultSet resultSet=statement.executeQuery("select * from employees");
		List<Employees> employeesList=new ArrayList<>();
		while(resultSet.next()) {
			Employees employee=new Employees();
			employee.setId(resultSet.getInt("emp_id"));
			employee.setFirstName(resultSet.getString("first_name"));
			employee.setLastName(resultSet.getString("last_name"));
			employee.setDesignation(resultSet.getString("emp_designation"));
			employeesList.add(employee);
		}
		ConnectionManager.closeConnection();
		return employeesList;
	}

	@Override
	public int save(Employees employees) throws ClassNotFoundException, SQLException {
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement statement=
				connection.prepareStatement("insert into employees values(?,?,?,?)");
		statement.setInt(1, employees.getId());
		statement.setString(2, employees.getFirstName());
		statement.setString(3, employees.getLastName());
		statement.setString(4, employees.getDesignation());
		
		int rows=statement.executeUpdate();
		ConnectionManager.closeConnection();
		return rows;
	}

}
