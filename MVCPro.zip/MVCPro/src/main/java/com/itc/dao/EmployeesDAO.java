package com.itc.dao;

import java.sql.SQLException;
import java.util.List;

import com.itc.entities.Employees;

public interface EmployeesDAO {
	
	List<Employees> get()throws ClassNotFoundException, SQLException;
	int save(Employees employees)throws ClassNotFoundException, SQLException;

}
