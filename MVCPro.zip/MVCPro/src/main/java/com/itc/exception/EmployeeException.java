package com.itc.exception;

public class EmployeeException extends Exception {
	String message;

	public EmployeeException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
	

}
