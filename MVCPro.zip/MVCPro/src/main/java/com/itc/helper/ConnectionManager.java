package com.itc.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager {
	private static Connection connection=null;
	
	public static Connection openConnection() throws ClassNotFoundException, SQLException{
		Class.forName("oracle.jdbc.OracleDriver");
		connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:FREE",
				"C##ITCUSER","itcuser");
		return connection;
	}
	public static void closeConnection() throws SQLException {
		connection.close();
	}

}
