package com.itc.controller;

import jakarta.servlet.http.HttpServlet;
import java.io.IOException;
import java.util.List;

import com.itc.service.EmployeesServiceImpl;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.Servlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.itc.exception.EmployeeException;
import com.itc.model.EmployeesModel;
import com.itc.service.EmployeesService;

/**
 * Servlet implementation class EmployeeControllerClass
 */
@WebServlet(name = "EmployeeController", urlPatterns = { "/employees" })
public class EmployeeControllerClass extends HttpServlet implements Servlet {
	private static final long serialVersionUID = 1L;
	private EmployeesService employeeService=new EmployeesServiceImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeControllerClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			List<EmployeesModel> employeesList=employeeService.retrieveEmployees();
			request.setAttribute("employeesList",employeesList);
			RequestDispatcher dispatcher=request.getRequestDispatcher("employeedetails.jsp");
			dispatcher.forward(request, response);
		} catch (EmployeeException e) {
			RequestDispatcher dispatcher=request.getRequestDispatcher("error.jsp");
			dispatcher.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id=Integer.parseInt(request.getParameter("id"));
		String firstname=request.getParameter("firstname");
		String lastname=request.getParameter("lastname");
		String designation=request.getParameter("designation");
		EmployeesModel model=new EmployeesModel();
		model.setId(id);
		model.setFirstName(firstname);
		model.setLastName(lastname);
		model.setDesignation(designation);
		try {
			String result=employeeService.saveEmployees(model);
			if(result.equals("success")) {
				RequestDispatcher dispatcher=request.getRequestDispatcher("success.jsp");
				dispatcher.forward(request, response);
			}else {
				RequestDispatcher dispatcher=request.getRequestDispatcher("error.jsp");
				dispatcher.forward(request, response);
			}
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

}
