<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" isELIgnored="false"%>
 <%@taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<table border="2" cellspacing="2" cellpadding="2">
<tr>
<th>Employee Id#</th><th>First Name</th><th>Last Name</th><th> Designation</th>
</tr>
<c:forEach items="${employeesList}" var="model">
<tr>
<td>
<c:out value="${model.id}"/>
</td>
<td>
<c:out value="${model.firstName}"/>
</td>
<td>
<c:out value="${model.lastName}"/>
</td>
<td>
<c:out value="${model.designation}"/>
</td>
</tr>
</c:forEach>

</table>
</body>
</html>