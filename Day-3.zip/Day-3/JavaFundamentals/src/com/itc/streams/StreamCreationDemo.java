package com.itc.streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.stream.Collectors;

import com.itc.entities.Employee;

public class StreamCreationDemo {

	public static void main(String[] args) {
		
		int[] numbers= {8,5,7,8,2,1};
		long countEvenNumber=Arrays
		.stream(numbers)
		.filter((number)->number%2==0)
		.count();
		System.out.println("countEvenNumber->"+countEvenNumber);
		
		System.out.println("============================");
		//Streams are immutable
		Arrays
		.stream(numbers)
		.map((n)->n*2)
		.forEach(System.out::println);
		System.out.println("============================");
		//original array
		System.out.println(Arrays.toString(numbers));
		
		//Create Stream from Collection
		int[] scores=new int[10];
		
		List<Integer> listOfInteger= new ArrayList<>();
		listOfInteger.add(78);
		listOfInteger.add(23);
		listOfInteger.add(56);
		listOfInteger.add(31);
		OptionalInt max=listOfInteger
		.stream()
		.mapToInt(Integer::intValue)
		.max();
         if(max.isPresent())
        	 System.out.println("Max:"+max.getAsInt());
         
         
         for(Iterator<Integer> iterator=listOfInteger.iterator();iterator.hasNext();) {
        	   System.out.println( iterator.next());
         }
         System.out.println("======================================");
         List<Integer> marks=new ArrayList<>();
         marks.add(71);
         marks.add(73);
         marks.add(89);
         
         ListIterator<Integer> marksIterator=marks.listIterator();
         while(marksIterator.hasNext()) {
        	 marksIterator.next();
         }
         while(marksIterator.hasPrevious()) {
        	 System.out.println(marksIterator.previous());
         }
         
         Set<String> setOfString=new HashSet<>();
         setOfString.add("sabbir");
         setOfString.add("sabbir");
         setOfString.add("chirag");
         System.out.println(setOfString);
         
         System.out.println("==========================================");
         setOfString
         .stream()
         .peek(System.out::println)
         .map(String::toUpperCase)
         .peek(System.out::println)
         .collect(Collectors.toList())
         .forEach(System.out::println);
         
        // System.out.println("countOfNames->"+countOfNames);
         System.out.println("==========================================");
         Map<Integer,String> employeedetails=new HashMap<>();
         System.out.println(employeedetails.put(101, "sabbir"));
         System.out.println(employeedetails.put(102, "amit"));
         System.out.println( employeedetails.put(101, "purohit"));
         Optional<Integer> maxKey=employeedetails
         .keySet()
         .stream()
         .max(Integer::compare);
         if(maxKey.isPresent())
        	 System.out.println("maxKey->"+maxKey.get());
         System.out.println("==========================================");
         Set<Entry<Integer,String>> entries=employeedetails.entrySet();
         Iterator<Entry<Integer,String>> entriesIterator=entries.iterator();
         while(entriesIterator.hasNext()) {
        	 Map.Entry<Integer,String> entry=entriesIterator.next();
        	 System.out.println("Key:"+entry.getKey());
        	 System.out.println("Value:"+entry.getValue());
         }
         System.out.println("===================================");
         SortedSet<Employee> employees=new TreeSet<Employee>();
         employees.add(new Employee(102,"sabbir"));
         employees.add(new Employee(101,"amit"));
         employees.add(new Employee(103,"rohit"));
         System.out.println(employees);
         
         SortedSet<Employee> employeesComparator=new TreeSet<Employee>(
        		 new Comparator<Employee>() {

					@Override
					public int compare(Employee o1, Employee o2) {
						// TODO Auto-generated method stub
						if(o1.getEmpNo()>o2.getEmpNo())
							return 1;
						else if(o1.getEmpNo()<o2.getEmpNo())
							return -1;
						return 0;
					}
        			 
        		 }
        		 
        		 );
         System.out.println("===============================");
         employeesComparator.add(new Employee(102,"sabbir"));
         employeesComparator.add(new Employee(101,"amit"));
         employeesComparator.add(new Employee(103,"rohit"));
         System.out.println(employeesComparator);
         System.out.println("===============================");
         SortedSet<Employee> employeesComparatorLambda=new TreeSet<Employee>(
        		 
        		 (e1,e2)->{
        			 if(e1.getEmpNo()>e2.getEmpNo())
							return 1;
						else if(e1.getEmpNo()<e2.getEmpNo())
							return -1;
						return 0;
        		 }
        		 );
         employeesComparatorLambda.add(new Employee(102,"sabbir"));
         employeesComparatorLambda.add(new Employee(101,"amit"));
         employeesComparatorLambda.add(new Employee(103,"rohit"));
         System.out.println(employeesComparatorLambda);
         
         
  
	}

}
