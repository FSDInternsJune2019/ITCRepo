package com.itc.demo;

import java.time.LocalDate;
import java.time.Month;

import com.itc.entities.Visitor;
import com.itc.entities.Admin;
import com.itc.entities.User;

public class InheritanceDemo {

	public static void main(String[] args) {
		User user=null;
		user=new Visitor("sabbir","sabbir123","sabbir","poonawala",
				LocalDate.of(1978, Month.OCTOBER, 1),"male",
				1001);
		
		
		System.out.println(user.login());
		
		user=new Admin("adminuser","admin@123","rakesh","patel",
				
				LocalDate.of(1978, Month.OCTOBER, 1),
				"male",1);
		System.out.println(user.login());
		

	}

}
