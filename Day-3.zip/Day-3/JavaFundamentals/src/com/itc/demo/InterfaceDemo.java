package com.itc.demo;

import com.itc.service.CImpl;
import com.itc.service.C;
public class InterfaceDemo {

	public static void main(String[] args) {
		C c=new CImpl();
		c.a();
		
		//Runnable r=new CImpl();

	}

}
