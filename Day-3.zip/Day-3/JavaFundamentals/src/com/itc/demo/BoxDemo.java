package com.itc.demo;

import com.itc.entities.Box;

public class BoxDemo {

	public static void main(String[] args) {
		Box defaultBox=new Box();
		double defaultResult=defaultBox.area();
		System.out.println("defaultResult->"+defaultResult);
		
		Box squareBox=new Box(10);
		System.out.println(squareBox);
		
		Box rectangleBox1=new Box(10,20);
		Box rectangleBox2=new Box(10,20);
		
		if(rectangleBox1==rectangleBox2)
			System.out.println("rectangleBox1==rectangleBox2");
		
		if(rectangleBox1.equals(rectangleBox2))
			System.out.println("rectangleBox1.equals(rectangleBox2)");

		if(rectangleBox1.equals("SABBIR"))
			System.out.println("rectangleBox1.equals(rectangleBox2)");
		
		System.out.println("rectangleBox1->"+rectangleBox1.hashCode());
		System.out.println("rectangleBox2->"+rectangleBox2.hashCode());
	}

}
