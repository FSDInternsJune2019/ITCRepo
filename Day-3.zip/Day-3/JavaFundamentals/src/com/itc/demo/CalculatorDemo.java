package com.itc.demo;

import com.itc.service.Calculator;

public class CalculatorDemo {

	public static void main(String[] args) {
		
		Calculator calculator=new Calculator();
		System.out.println("Add two numbers->"+calculator.add(10,20));
		System.out.println("Add two floating point numbers->"+calculator.add(10.4f,20.9f));
		System.out.println("Add three numbers->"+calculator.add(10,20,30));
		//int[] arguments= {10,20,30,40,50};
		//System.out.println("Add n numbers->"+calculator.add(new int[] {10,20,30,40}));
		System.out.println("Add n numbers->"+calculator.add(10,20,30,40));

	}

}
