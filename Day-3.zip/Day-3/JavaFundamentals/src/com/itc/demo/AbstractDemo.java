package com.itc.demo;

import com.itc.service.Figure;
import com.itc.service.Rectangle;
import com.itc.service.Square;

public class AbstractDemo {

	public static void main(String[] args) {
		
		Figure figRef=null;
		figRef=new Square(10);
		System.out.println("Square->"+figRef.area());
		figRef=new Rectangle(10,20);
		System.out.println("Rectangle->"+figRef.area());
	}

}
