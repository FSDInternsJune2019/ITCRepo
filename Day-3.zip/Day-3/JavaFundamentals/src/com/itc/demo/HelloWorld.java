package com.itc.demo;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("HelloWorld!");
		while(true) {
			
		}

	}

}
