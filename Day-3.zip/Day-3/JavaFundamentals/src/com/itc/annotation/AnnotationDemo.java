package com.itc.annotation;

public class AnnotationDemo {
	@Deprecated
	/**
	 * x() has performance issues
	 * @see xNew
	 */
	public void x() {
		//computation
	}
	public void xNew() {
		//better computation
	}
	  @SuppressWarnings(value = {"unused"})
	public static void main(String[] args) {
		int i=20;
		AnnotationDemo o=new AnnotationDemo();
		o.x();
	}

}
