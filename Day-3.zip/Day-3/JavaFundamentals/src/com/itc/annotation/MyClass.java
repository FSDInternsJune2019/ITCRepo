package com.itc.annotation;
@ITCClass
public class MyClass {
	@Documentation(authorName = "Sabbir",companyName = "ITC")
	public void someMethod() {
		
	}

}
