package com.itc.annotation;

import java.lang.reflect.Method;

public class AnnotationProcessingDemo {

	public static void main(String[] args) throws NoSuchMethodException {
		
		//1. get class data
		Class<MyClass> classData=MyClass.class;
		//2. Determine if annotation is found in class data
		ITCClass found=(ITCClass)classData.getAnnotation(ITCClass.class);
		if(found!=null)
			System.out.println("Treat it as ITCClass");
		else
			System.out.println("Treat it as Ordinary class");
		
		Method someMethod=classData.getMethod("someMethod");
		Documentation docFound=(Documentation)someMethod.getAnnotation(Documentation.class);
		if(docFound!=null) {
			System.out.println("Author Name->"+docFound.authorName());
			System.out.println("Description->"+docFound.description());
			System.out.println("Company Name->"+docFound.companyName());
		}else {
			System.out.println("No documentation annotation found");
		}

	}

}
