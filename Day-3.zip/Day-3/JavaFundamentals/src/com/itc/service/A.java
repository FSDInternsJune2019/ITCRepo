package com.itc.service;

public interface A {
  void a();
 
  
}
