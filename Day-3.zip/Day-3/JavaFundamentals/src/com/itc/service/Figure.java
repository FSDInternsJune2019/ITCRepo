package com.itc.service;

public abstract class Figure {

	public abstract double area();
}
