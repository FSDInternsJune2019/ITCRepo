package com.itc.service;
import static java.lang.Math.*;
public class Calculator {
	
	public int add(int no1,int no2){
		return no1+no2;
	}
	
	public int add(int no1,int no2,int no3) {
		return no1+no2+no3;
	}
	
	public float add(float no1,float no2) {
		return no1+no2;
	}
	/*
	public int add(int[] n) {
		int total=0;
		for(int i:n) {
			total+=i;
		}
		return total;
	}*/
	
	public int add(int ...n) {
		int total=0;
		for(int i:n) {
			total+=i;
		}
		return total;
	}
	
	public double compute(double a,double b) {
		return sin(a)*cos(b)/PI;
	}

	
}
