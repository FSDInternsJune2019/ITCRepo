package com.itc.service;

public interface C extends A,B {
 void c();
}
