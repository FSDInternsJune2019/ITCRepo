package com.itc.service;

public interface B extends A{

	void b();
}
