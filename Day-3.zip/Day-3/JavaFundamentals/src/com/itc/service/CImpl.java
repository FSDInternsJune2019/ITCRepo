package com.itc.service;

public class CImpl implements C {

	@Override
	public void a() {
		System.out.println("a");
		
	}

	@Override
	public void b() {
		System.out.println("b");
	}

	@Override
	public void c() {
		System.out.println("c");
		
	}

}
