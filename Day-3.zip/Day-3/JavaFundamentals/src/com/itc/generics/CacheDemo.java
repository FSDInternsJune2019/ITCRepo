package com.itc.generics;

public class CacheDemo {

	public static void main(String[] args) {
		Cache<String> cacheOfString=new Cache<>();
		cacheOfString.setData("Sabbir");
		//cacheOfString.setData(10);
		

	}

}
