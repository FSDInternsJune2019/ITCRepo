package com.itc.inbuiltfunctionalinterfaces;

import java.util.function.Function;

public class FunctionDemo {

	  void main(String[] args) {
		Function<String,Integer> converter1=(s)->{
			return Integer.parseInt(s);
		};
		
		int result1=converter1.apply("200")*10;
		System.out.println("result1->"+result1);
		
		Function<String,Integer> converter2=(s)->Integer.parseInt(s);
		int result2=converter2.apply("200")*10;
		System.out.println("result2->"+result2);
		
		Function<String,Integer> converter3=Integer::parseInt;
		int result3=converter3.apply("200")*10;
		System.out.println("result3->"+result3);

	}

}
