package com.itc.inbuiltfunctionalinterfaces;

import java.util.function.UnaryOperator;

public class UnaryOperatorDemo {

	public static void main(String[] args) {
		UnaryOperator<String> changeCase=(s)->s.toUpperCase();
		System.out.println(changeCase.apply("sabbir"));

	}

}
