package com.itc.inbuiltfunctionalinterfaces;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class ConsumerDemo {
	
	public static <T> void print(List<T> list,Consumer<T> consumer){
		for(T t:list) {
			consumer.accept(t);
		}
	}
	

	public static void main(String[] args) {
		
		Consumer<String> consumerOfString=s->{
			System.out.println(s);
		};
		consumerOfString.accept("ITC");
		
		Consumer<String> consumerOfStringCompact=System.out::println;
		consumerOfStringCompact.accept("ITC");
		
		List<Integer> numbers=Arrays.asList(10,20,30,40,50);
		Consumer<Integer> consumerOfInteger=i->{
			System.out.println("Using Reference Variable"+i);
		};
		
		print(numbers,consumerOfInteger);
		print(numbers,(i)->{
			System.out.println("Using Lambda expression"+i);
		});
		print(numbers,System.out::println);
		
		numbers.forEach((i)->{
			System.out.println(i);
		});
		numbers.forEach(System.out::println);
		
		

	}

}
