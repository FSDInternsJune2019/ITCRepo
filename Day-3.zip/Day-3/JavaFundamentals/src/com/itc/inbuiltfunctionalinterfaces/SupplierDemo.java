package com.itc.inbuiltfunctionalinterfaces;

import java.util.function.Supplier;

import com.itc.entities.Employee;

public class SupplierDemo {
	
	class Inner implements Supplier<Employee>{

		@Override
		public Employee get() {
			return new Employee(101,"Sabbir");
		}
		
	}
	
	public static String customMethod(){
		return "ITC Infotech".toUpperCase();
	}

	public static void main(String[] args) {
		
		Supplier<String> supplierOfString1=()->{
			return "ITC Infotech".toUpperCase();
		};
		System.out.println("supplierOfString1->"+supplierOfString1.get());
		
		Supplier<String> supplierOfString2=new String("ITC Infotech")::toUpperCase;
		System.out.println("supplierOfString2->"+supplierOfString2.get());
		
		Supplier<String> supplierOfString3=SupplierDemo::customMethod;
		System.out.println("supplierOfString3->"+supplierOfString3.get());


	}

}
