package com.itc.inbuiltfunctionalinterfaces;

public interface MainInterface {
	
	default void x(){
		
	}

	public static void main(String args[]) {
		System.out.println("Hey running interface");
	}
}
