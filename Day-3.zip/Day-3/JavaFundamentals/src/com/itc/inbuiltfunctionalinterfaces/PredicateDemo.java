package com.itc.inbuiltfunctionalinterfaces;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

public class PredicateDemo {
	
	public static <T> void filter(List<T> anyList,Predicate<T> predicate){
		for(T t:anyList) {
			if(predicate.test(t)) {
				System.out.println(t);
			}
		}
	}

	public static void main(String[] args) {
		
		String name=null;
		Predicate<String> checkIfNull=Objects::isNull;
        boolean result=checkIfNull.test(name);
        System.out.println("result->"+result);
        
        Predicate<String> checkLength=(s)->s.length()>5;
        boolean result1=checkLength.test("sabbir");
        System.out.println("result1->"+result1);
        
       List<Integer> numbers= Arrays.asList(23,42,67,89,81);
       Predicate<Integer> checkIfEven=(n)->n%2==0;
       filter(numbers,checkIfEven);
       filter(numbers,(n)->n%2==0);
       
       List<String> names=Arrays.asList("sabbir","sumeet","raj");
       Predicate<String> checkNameStartsWithsEndsWithr=(firstname)->firstname.startsWith("s")
    		   && firstname.endsWith("r");
       
       filter(names,checkNameStartsWithsEndsWithr);
       
       Predicate<String> checkNameStartsWiths=(s)->s.startsWith("s");
       Predicate<String> checkEndsWithr=(s)->s.endsWith("r");
       
       filter(names,checkNameStartsWiths.and(checkEndsWithr));
       
       
	}

}
