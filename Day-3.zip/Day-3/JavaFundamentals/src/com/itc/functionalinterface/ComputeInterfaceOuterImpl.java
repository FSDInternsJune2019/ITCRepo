package com.itc.functionalinterface;

public class ComputeInterfaceOuterImpl implements ComputeInterface{

	public double existingNonStatic(double a,double b) {
		return (a*a)/(b*b);
	}
	public static double existingStatic(double a,double b) {
		return a*Math.PI/Math.cos(b);
	}

	@Override
	public double compute(double a, double b) {
		// TODO Auto-generated method stub
		return a+b;
	}
	class ComputeIntefaceInnerImpl implements ComputeInterface{
	@Override
	public double compute(double a, double b) {
		// TODO Auto-generated method stub
		return a-b;
	}
	}
	public static void main(String[] args) {
		ComputeInterfaceOuterImpl outer=new ComputeInterfaceOuterImpl();
		System.out.println("outer->"+outer.compute(12, 30));
		
		ComputeInterfaceOuterImpl.ComputeIntefaceInnerImpl inner=
				outer.new ComputeIntefaceInnerImpl();
		System.out.println("Inner->"+inner.compute(25,21));
		
		ComputeInterface annoymous=new ComputeInterface() {

			@Override
			public double compute(double a, double b) {
				// TODO Auto-generated method stub
				return a*b;
			}
			
		};
		
      System.out.println("annoymous->"+annoymous.compute(20,90));
      ComputeInterface div=(a,b)->{
    	  return a/b;
      };
      System.out.println("div->"+div.compute(21, 30));
      
      ComputeInterface squareSum=(a,b)->a*a+b*b;
      System.out.println("squareSum->"+squareSum.compute(21, 30));
      
      ComputeInterface methodRefNonStatic= new ComputeInterfaceOuterImpl()::existingNonStatic;
      
      System.out.println("methodRefNonStatic->"+methodRefNonStatic.compute(20, 50));
      
      ComputeInterface methodRefStatic=ComputeInterfaceOuterImpl::existingStatic;
      System.out.println("methodRefStatic->"+methodRefStatic.compute(10, 20));
      
	}
}
