package com.itc.functionalinterface;

import com.itc.entities.Employee;

public class MethodRefDemo {

	public static void main(String[] args) {
		
		EmployeeFactory factory1=(empNo,empName)->{
			return new Employee(empNo,empName);
		};
		System.out.println(factory1.create(101, "sabbir"));
		
		EmployeeFactory factory2=(empNo,empName)->new Employee(empNo,empName);
		System.out.println(factory2.create(102, "amit"));
		
		EmployeeFactory factory3=Employee::new;
		System.out.println(factory3.create(103, "rohit"));
	}

}
