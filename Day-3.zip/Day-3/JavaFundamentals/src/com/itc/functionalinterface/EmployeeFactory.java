package com.itc.functionalinterface;

import com.itc.entities.Employee;

@FunctionalInterface
public interface EmployeeFactory {

	Employee create(int empNo,String empName);
}
