package com.itc.functionalinterface;

public interface ComputeInterface {
	
	double compute(double a,double b);

}
