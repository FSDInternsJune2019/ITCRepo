package com.itc.exception;

public class ThrowsDemo {
	
	public void x(int no1,int no2) throws ArithmeticException {
		int result=no1/no2;
	}
	
	public void y() throws ArithmeticException {
		x(10,0);
	}

	public static void main(String[] args) {
		System.out.println("--Application started--");
		
		ThrowsDemo o=new ThrowsDemo();
		try {
		o.y();
		}catch(ArithmeticException e) {}
		System.out.println("--Application stopped--");

	}

}
