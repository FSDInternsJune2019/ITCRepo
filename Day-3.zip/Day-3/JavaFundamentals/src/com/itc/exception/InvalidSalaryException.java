package com.itc.exception;

public class InvalidSalaryException extends Exception {
	
	private String message;

	public InvalidSalaryException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
	

}
