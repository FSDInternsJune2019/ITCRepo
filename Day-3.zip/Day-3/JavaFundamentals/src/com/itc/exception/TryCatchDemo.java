package com.itc.exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TryCatchDemo {

	public static void main(String[] args) {
		System.out.println("--Application Started---");
		
		try(Scanner scanner=new Scanner(System.in);)
		
		{
		System.out.println("Please Enter Salary:");
		double salary=scanner.nextDouble();
		if(salary<0)
			throw new InvalidSalaryException("Salary cannot be negative");
		double tax=salary*0.01;
		System.out.println("Tax->"+tax);
		}catch(InputMismatchException | ArithmeticException e) {
			System.err.println("Invalid salary entered");
		}
		catch(InvalidSalaryException e) {
			System.err.println("Salary cannot be negative");
		}
		catch(Exception e) {
			System.err.println("Internal error processing request");
		}
		System.out.println("--Application Stopped---");

	}

}
