package com.itc.enums;

public class Computer {
	
	enum STATE{
		ON(1),OFF(0),SUSPEND(2);
		private int val;
		private STATE(int val) {
			this.val=val;
		}
		public int getVal() {
			return val;
		}
	}
	
	public void setState(STATE state) {
		//do something
		switch(state) {
		case ON: System.out.println("Switch ON");
		         break;
		case OFF:System.out.println("Switch OFF");
		         break;
		case SUSPEND: System.out.println("SUSPEND");
		         break;
		
		}
	}
	
	public static void main(String[] args) {
		
		Computer computer=new Computer();
		computer.setState(STATE.OFF);
		
		computer.setState(STATE.ON);
		
		//computer.setState(72);
	}

}
