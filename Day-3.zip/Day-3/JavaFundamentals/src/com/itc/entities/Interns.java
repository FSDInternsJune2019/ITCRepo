package com.itc.entities;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class Interns {
	private Interns() {}
	
	private Interns(Interns.Builder builder) {
		this.id=builder.id;
		this.firstname=builder.firstname;
		this.lastname=builder.lastname;
		this.age=builder.age;
		this.grade=builder.grade;
	}
	
	private int id;
	private String firstname;
	private String lastname;
	private int age;
	private char grade;
	
	static private class Builder{
		private int id;
		private String firstname;
		private String lastname;
		private int age;
		private char grade;
		
		public Builder setId(int id) {
			this.id=id;
			return this;
		}
		public Builder setFirstname(String firstname) {
			this.firstname=firstname;
			return this;
		}
		public Builder setLastname(String lastname) {
			this.lastname=lastname;
			return this;
		}
		public Builder setAge(int age) {
			this.age=age;
			return this;
		}
		public Builder setGrade(char grade) {
			this.grade=grade;
			return this;
		}
		public Interns build() {
			return new Interns(this);
		}
		
	}
	
	public static List<Interns> createInternsList(){
		return Arrays.asList(
				new Interns.Builder()
				.setId(1001)
				.setFirstname("sabbir")
				.setLastname("poonawala")
				.setAge(21)
				.setGrade('A')
				.build()
				
		);
	}

	public int getId() {
		return id;
	}

	public String getFirstname() {
		return firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public int getAge() {
		return age;
	}

	public char getGrade() {
		return grade;
	}

	@Override
	public int hashCode() {
		return Objects.hash(Integer.valueOf(age), firstname, Character.valueOf(grade), Integer.valueOf(id), lastname);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Interns other = (Interns) obj;
		return age == other.age && Objects.equals(firstname, other.firstname) && grade == other.grade && id == other.id
				&& Objects.equals(lastname, other.lastname);
	}

	@Override
	public String toString() {
		return "Interns [id=" + id + ", firstname=" + firstname + ", lastname=" + lastname + ", age=" + age + ", grade="
				+ grade + "]";
	}

}
