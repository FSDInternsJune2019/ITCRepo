package com.itc.entities;

import java.time.LocalDate;
import java.util.Objects;

public non-sealed class Admin extends User {
	private int adminId;
	
	public Admin(String username,String password,String firstname,
			String lastname,
			LocalDate dateOfBirth,String gender,int adminId) {
		
		this.adminId=adminId;
		super(username,password,firstname,lastname,dateOfBirth,
				gender);
	}

	public int getAdminId() {
		return adminId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(adminId);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Admin other = (Admin) obj;
		return adminId == other.adminId;
	}

	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + "]";
	}
	@Override
	public boolean login() {
		if(getUsername().equalsIgnoreCase("adminuser")
				&& getPassword().equals("admin@123") 
				&& adminId==1) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
}
