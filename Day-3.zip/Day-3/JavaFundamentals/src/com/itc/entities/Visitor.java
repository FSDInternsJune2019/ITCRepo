package com.itc.entities;

import java.time.LocalDate;
import java.util.Objects;

public non-sealed class Visitor extends User {
	
	private int visitorId;
	public Visitor(String username, String password, String firstname, String lastname, LocalDate dateOfBirth,
			String gender, int visitorId) {
		super(username,password,firstname,
				lastname,dateOfBirth,gender);
		
		this.visitorId = visitorId;
	}
	
	public int getVisitorId() {
		return visitorId;
	}
	@Override
	public int hashCode() {
		return Objects.hash(getDateOfBirth(), getFirstname(), getGender(), getLastname(), getPassword(), getUsername(), Integer.valueOf(visitorId));
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Visitor other = (Visitor) obj;
		return Objects.equals(getDateOfBirth(), other.getDateOfBirth()) && Objects.equals(getFirstname(), other.getFirstname())
				&& Objects.equals(getGender(), other.getGender()) && Objects.equals(getLastname(), other.getLastname())
				&& Objects.equals(getPassword(), other.getPassword()) && Objects.equals(getUsername(), other.getUsername())
				&& visitorId == other.visitorId;
	}
	@Override
	public String toString() {
		return "Visitor [username=" + getUsername() + ", password=" + getPassword() + ", firstname=" + getFirstname() + ", lastname="
				+ getLastname() + ", dateOfBirth=" + getDateOfBirth() + ", gender=" + getGender() + ", visitorId=" + visitorId + "]";
	}
	@Override
	public boolean login() {
		if(getUsername().equalsIgnoreCase("sabbir")
				&& getPassword().equals("sabbir123") 
				&& visitorId==1001) {
			return true;
		}
		else {
			return false;
		}
	}
	

}
