package com.itc.entities;

import java.time.LocalDate;
import java.util.Objects;

public sealed class User permits Visitor,Admin {
	
	private String username;
	private String password;
	private String firstname;
	private String lastname;
	private LocalDate dateOfBirth;
	private String gender;
	public User() {}
	
	public User(String username, String password, String firstname, String lastname, LocalDate dateOfBirth,
			String gender) {
		super();
		this.username = username;
		this.password = password;
		this.firstname = firstname;
		this.lastname = lastname;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
	}
	public String getUsername() {
		return username;
	}
	public String getPassword() {
		return password;
	}
	public String getFirstname() {
		return firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public String getGender() {
		return gender;
	}
	@Override
	public int hashCode() {
		return Objects.hash(dateOfBirth, firstname, gender, lastname, password, username);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		return Objects.equals(dateOfBirth, other.dateOfBirth) && Objects.equals(firstname, other.firstname)
				&& Objects.equals(gender, other.gender) && Objects.equals(lastname, other.lastname)
				&& Objects.equals(password, other.password) && Objects.equals(username, other.username);
	}
	@Override
	public String toString() {
		return "User [username=" + username + ", password=" + password + ", firstname=" + firstname + ", lastname="
				+ lastname + ", dateOfBirth=" + dateOfBirth + ", gender=" + gender + "]";
	}
	
	public boolean login() {
		if(username.equalsIgnoreCase("sabbir")
				&& password.equals("sabbir123")) {
			return true;
		}
		else {
			return false;
		}
	}
	

}
