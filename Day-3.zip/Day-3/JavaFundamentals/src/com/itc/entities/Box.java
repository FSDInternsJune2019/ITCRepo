package com.itc.entities;

public class Box {
	private double length;
	private double breadth;
	
	public Box() {
		this.length=-1;
		this.breadth=-1;
	}
	
	public Box(double length) {
		this.length=length;
		this.breadth=length;
		
	}
	
	public Box(double length,double breadth) {
		this.length=length;
		this.breadth=breadth;
	}
	
	public double area(){
		return length*breadth;
	}
	@Override
	public String toString(){
		StringBuilder sb=new StringBuilder("[Box->");
		sb.append("length:"+length+",");
		sb.append("breadth:"+breadth);
		sb.append("]");
		return sb.toString();
	}
	@Override
	public boolean equals(Object o){
		if(o!=null && o instanceof Box) {
			Box boxArg=(Box)o;
			if(this.length==boxArg.length && this.breadth==boxArg.breadth) {
				return true;
			}
		}
		return false;
	}
	@Override
	public int hashCode(){
		return (int)length ^ (int)breadth;
	}
}
