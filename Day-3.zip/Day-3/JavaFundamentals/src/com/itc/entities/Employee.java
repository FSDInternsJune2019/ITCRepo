package com.itc.entities;

import java.util.Objects;

public final class Employee implements Comparable<Employee>{
	private int empNo;
	private String empName;
	public Employee(int empNo, String empName) {
		super();
		this.empNo = empNo;
		this.empName = empName;
	}
	public int getEmpNo() {
		return empNo;
	}
	public String getEmpName() {
		return empName;
	}
	@Override
	public int hashCode() {
		return Objects.hash(empName, Integer.valueOf(empNo));
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return Objects.equals(empName, other.empName) && empNo == other.empNo;
	}
	@Override
	public String toString() {
		return "Employee [empNo=" + empNo + ", empName=" + empName + "]";
	}
	@Override
	public int compareTo(Employee o) {
		if(this.empNo>o.empNo)
			return 1;
		else if(this.empNo<o.empNo)
			return -1;
		return 0;
	}
	

}
