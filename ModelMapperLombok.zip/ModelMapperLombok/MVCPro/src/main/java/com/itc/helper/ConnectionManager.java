package com.itc.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager {
	private static Connection connection=null;
	
	private static DataSource dataSource=new DataSource("db");
	
	public static Connection openConnection() throws ClassNotFoundException, SQLException{
		Class.forName(dataSource.getDriver());
		connection=DriverManager.getConnection(dataSource.getUrl(),
				dataSource.getDbuser(),dataSource.getDbpassword());
		return connection;
	}
	public static void closeConnection() throws SQLException {
		connection.close();
	}

}
