package com.itc.helper;

import java.util.Objects;
import java.util.ResourceBundle;

public class DataSource {
  private String driver;
  private String url;
  private String dbuser;
  private String dbpassword;
  public DataSource() {}
  public DataSource(String baseName) {
	 ResourceBundle rb= ResourceBundle.getBundle(baseName);
	 this.driver=rb.getString("driver");
	 this.url=rb.getString("url");
	 this.dbuser=rb.getString("dbusername");
	 this.dbpassword=rb.getString("dbpassword");
	  
  }
  public String getDriver() {
	return driver;
  }
  public String getUrl() {
	return url;
  }
  public String getDbuser() {
	return dbuser;
  }
  public String getDbpassword() {
	return dbpassword;
  }
  @Override
  public String toString() {
	return "DataSource [driver=" + driver + ", url=" + url + ", dbuser=" + dbuser + ", dbpassword=" + dbpassword + "]";
  }
  @Override
  public int hashCode() {
	return Objects.hash(dbpassword, dbuser, driver, url);
  }
  @Override
  public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	DataSource other = (DataSource) obj;
	return Objects.equals(dbpassword, other.dbpassword) && Objects.equals(dbuser, other.dbuser)
			&& Objects.equals(driver, other.driver) && Objects.equals(url, other.url);
  }
  
  
}
