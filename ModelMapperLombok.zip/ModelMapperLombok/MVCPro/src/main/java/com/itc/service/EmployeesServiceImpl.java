package com.itc.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.modelmapper.ModelMapper;

import com.itc.dao.EmployeesDAOImpl;
import com.itc.entities.Employees;
import com.itc.exception.EmployeeException;
import com.itc.model.EmployeesModel;
import com.itc.dao.EmployeesDAO;


public class EmployeesServiceImpl implements EmployeesService {

	private EmployeesDAO employeesDAO=new EmployeesDAOImpl();
	List<String> validDesignationsList=Arrays.asList("Consultant","Engineer");
	ModelMapper mapper=new ModelMapper();
	
	@Override
	public List<EmployeesModel> retrieveEmployees() throws EmployeeException {
		List<EmployeesModel> modelsList=new ArrayList<>();
		try {
			List<Employees> employeesList=employeesDAO.get();
			employeesList.forEach((employee)->{
				/*
				EmployeesModel model=new EmployeesModel();
				
				model.setId(employee.getId());
				model.setFirstName(employee.getFirstName().toUpperCase());
				model.setLastName(employee.getLastName().toUpperCase());
				model.setDesignation(employee.getDesignation());*/
				EmployeesModel model=mapper.map(employee, EmployeesModel.class);
				modelsList.add(model);
			});
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(modelsList.isEmpty())
			throw new EmployeeException("Employee records not found");
		return modelsList;
	}

	@Override
	public String saveEmployees(EmployeesModel employeesModel) throws EmployeeException {
		if(employeesModel.getId()<0) {
			throw new EmployeeException("Employee Id cannot be negative");
		}
		if(!validDesignationsList.contains(employeesModel.getDesignation())) {
			throw new EmployeeException("Employee designation is invalid");

		}/*
		Employees employee=new Employees();
		employee.setId(employeesModel.getId());
		employee.setFirstName(employeesModel.getFirstName());
		employee.setLastName(employeesModel.getLastName());
		employee.setDesignation(employeesModel.getDesignation());*/
		Employees employee=mapper.map(employeesModel, Employees.class);
		String outcome=null;
		try {
			int rows=employeesDAO.save(employee);
			if(rows>0)
				outcome="success";
			else
				outcome="fail";
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return outcome;
	}

}
