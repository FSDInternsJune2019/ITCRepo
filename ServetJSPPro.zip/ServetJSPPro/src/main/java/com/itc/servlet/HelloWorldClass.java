package com.itc.servlet;

import jakarta.servlet.GenericServlet;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebServlet;

/**
 * Servlet implementation class HelloWorldClass
 */
@WebServlet(name = "HelloWorld", urlPatterns = { "/hello" })
public class HelloWorldClass extends GenericServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see GenericServlet#GenericServlet()
     */
    public HelloWorldClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		System.out.println("***********Servlet initialized***********");
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		System.out.println("***********Servlet destroyed***********");

	}

	/**
	 * @see Servlet#service(ServletRequest request, ServletResponse response)
	 */
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		BufferedReader buffer=new BufferedReader(new FileReader("C:\\IO\\data.txt"));
		String data=null;
		while((data=buffer.readLine())!=null) {
		out.println(data);
		}
		buffer.close();
	}

}
